import { Authenticated, Unauthenticated, useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useEffect, useState } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-50 to-pink-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold text-purple-600">Voice Assistant</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const history = useQuery(api.commands.getHistory);
  const saveCommand = useMutation(api.commands.saveCommand);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");

  useEffect(() => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const command = event.results[0][0].transcript.toLowerCase();
        setTranscript(command);
        processCommand(command);
      };

      recognition.onend = () => setListening(false);

      (window as any).recognition = recognition;
    }
  }, []);

  const startListening = () => {
    if ((window as any).recognition) {
      setListening(true);
      (window as any).recognition.start();
    }
  };

  const processCommand = async (command: string) => {
    let response = "";
    const synth = window.speechSynthesis;
    const voices = synth.getVoices();
    const femaleVoice = voices.find(voice => voice.name.includes('female')) || voices[0];
    
    if (command.includes('time')) {
      response = `The time is ${new Date().toLocaleTimeString()}`;
    } else if (command.includes('weather')) {
      response = "It's sunny and 72 degrees outside";
    } else if (command.includes('joke')) {
      response = "Why don't scientists trust atoms? Because they make up everything!";
    } else if (command.includes('reminder')) {
      response = "I've set a reminder for you";
    } else if (command.includes('open youtube')) {
      window.open('https://youtube.com', '_blank');
      response = "Opening YouTube";
    } else if (command.includes('open google')) {
      window.open('https://google.com', '_blank');
      response = "Opening Google";
    } else {
      response = "Sorry, I don't understand that command";
    }

    const utterance = new SpeechSynthesisUtterance(response);
    utterance.voice = femaleVoice;
    synth.speak(utterance);
    
    await saveCommand({ command, response });
  };

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold text-purple-600 mb-4">Voice Assistant</h1>
        <Authenticated>
          <div className="space-y-6">
            <div className="relative w-48 h-48 mx-auto">
              <div className={`absolute inset-0 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 ${listening ? 'animate-pulse' : ''}`}>
                <button
                  onClick={startListening}
                  className="w-full h-full flex items-center justify-center text-white"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="text-center text-gray-600">
              {listening ? "Listening..." : "Click the microphone to speak"}
            </div>
            
            {transcript && (
              <div className="text-center text-sm text-gray-500">
                Last command: "{transcript}"
              </div>
            )}

            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-4">Command History</h3>
              <div className="space-y-2">
                {history?.map((item) => (
                  <div key={item._id} className="bg-white p-3 rounded-lg shadow-sm">
                    <div className="font-medium text-purple-600">{item.command}</div>
                    <div className="text-sm text-gray-500">{item.response}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-gray-600">Sign in to get started</p>
          <SignInForm />
        </Unauthenticated>
      </div>
    </div>
  );
}
